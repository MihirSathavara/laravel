<!DOCTYPE html>
<html>
<head>
    <title>Laravel Form Validation</title>
</head>
<body>

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="#" method="post">
    @csrf
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" value="{{ old('name') }}">
    <br>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" value="{{ old('email') }}">
    <br>
    <label for="message">Message:</label>
    <textarea id="message" name="message"></textarea>
    <br>
    <button type="submit">Submit</button>
</form>

</body>
</html>
