<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Fvalidate;
use Validator;

class UserController extends Controller
{
    public function store(Request $request)
    {
        // Validate the form data
        $validator = Validator::make($request->all(), User::rules());

        if ($validator->fails()) {
            return redirect('/form')->withErrors($validator)->withInput();
        }

        // Save data to database (assuming valid)
        $user = User::create($request->all());

        // Process data further or redirect to success page

        return redirect('/success');
    }
}
