<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Fvalidate extends Model
{
    protected $fillable = [
        'name',
        'email',
        'message',
    ];

    // Define validation rules within the model (optional)
    public static function rules()
    {
        return [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email',
            'message' => 'required|string',
        ];
    }
}
