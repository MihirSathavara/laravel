<!DOCTYPE html>
<html>
<head>
    <title>Laravel Form Validation</title>
</head>
<body>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="#" method="post">
    <?php echo csrf_field(); ?>
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>">
    <br>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>">
    <br>
    <label for="message">Message:</label>
    <textarea id="message" name="message"></textarea>
    <br>
    <button type="submit">Submit</button>
</form>

</body>
</html>
<?php /**PATH D:\from-validation\resources\views/form.blade.php ENDPATH**/ ?>